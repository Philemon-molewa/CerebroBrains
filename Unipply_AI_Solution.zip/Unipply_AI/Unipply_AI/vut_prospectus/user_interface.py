class Interface:

    subjects_entered = 0  # number of subjects
    subject_len = 0
    aps = 0

    def __init__(self):
        self.nsc = []
        self.subject_list = {}

    def sub(self):
        # a list of national senior certificate subjects
        self.nsc = ["mathematics", "physical science", "life orientation", "english", "geography", "life science",
                    "mathematical literacy", "technical mathematics", "sepedi", "xitsonga", "isizulu", "isindebele",
                    "mathematics engineering", "engineering science", "tourism", "history", "sesotho", "setswan",
                    "siswati", "tshivenda", "afrikaans", "isixhosa", "business studies", "consumer studies",
                    "dramatic arts", "information technology", "accounting", "agricultural science", "music",
                    "religion studies", "visual arts", "economics", "engineering graphics and design"]

        while True:
            try:
                self.subject_len = int(input("How many subjects you did? "))
            except ValueError:
                print("Invalid value!")
                continue

            while True:
                try:
                    subject = input("Subject: ").lower()
                    if subject not in self.nsc:  # checking if the entered subject is in the list
                        print(f"Typing error! {subject} does not exist. Please enter again.")
                        continue

                    if subject in self.subject_list:  # check if the subject already entered
                        print(f"{subject} already exist!")
                        continue

                    while True:
                        level = int(input("Level: "))
                        if 1 <= level <= 7:
                            #  adding subject and level to the subject list
                            for i in range(self.subject_len):
                                self.subject_list[subject] = level
                        else:
                            print('Subject level must be between 1-7')
                            continue
                        break

                except ValueError:
                    (print("Error!, invalid value."))
                    continue
                self.subjects_entered += 1  # increment the number of subjects
                print("Number of subjects: ", self.subjects_entered)

                if self.subjects_entered == self.subject_len:
                    break

            # output of subjects entered
            print("\nYOUR RESULTS:")
            print(self.subject_list)
            break

    # calculating aps for all courses
    def calculate_aps(self):
        aps = sum(value for key, value in self.subject_list.items() if key != "life orientation")
        return aps
