from user_interface import Interface


class Faculty(Interface):

    def __init__(self):
        super().__init__()

        # COURSES FOR APPLIED COMPUTER SCIENCE FACULTY
        self.courses_applied_science = [
            {'course': 'Dip: Information Technology (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'technical mathematics': 4, 'mathematical literacy': 6}],
             'any_other_subj': 16,
             'aps_mathematics/technical_mathematics': 24,
             'aps_mathematical_literacy': 26},  # course 1

            {'course': 'Dip: Environmental Science (3years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4}],
             'any_other_subj': 9,
             'aps_mathematics': 24},  # course 2

            {'course': 'Dip: Agricultural Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4}],
             'any_other_subj': 11,
             'aps_mathematics': 24,
             'aps_mathematical_literacy': 25},  # course 3

            {'course': 'Dip: Biotechnology (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'mathematics engineering': 4, 'physical science': 4,
                  'life science': 4,
                  'life orientation': 3, 'engineering science': 4}],
             'any_other_subj': 7,
             'aps_mathematics/mathematics_engineering': 26},  # course 4

            {'course': 'Dip: Non-Destructive Testing (3 years)',
             'compulsory_subj': [
                 {'english': 3, 'mathematics': 3, 'technical mathematics': 4, 'physical science': 4,
                  'life orientation': 3},
                 {'english': 3, 'mathematics': 4, 'technical mathematics': 4, 'physical science': 3,
                  'life orientation': 3}],
             'any_other_subj': 9,
             'aps_mathematics': 22,
             'aps_technical_mathematics': 23},  # course 5

            {'course': 'Bachelor of Health  Science: Medical Laboratory Science (4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4, 'life science': 4, 'life orientation': 3}],
             'any_other_subj': 7,
             'aps_mathematics': 30},  # course 6

            {'course': 'Dip: Analytical Chemistry (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'engineering mathematics': 4, 'physical science': 4,
                  'engineering science': 4, 'life orientation': 3}],
             'any_other_subj': 9,
             'aps_mathematics/mathematics_engineering': 24}  # course 7
        ]

        # COURSES FOR HUMAN SCIENCE FACULTY
        self.courses_human_science = [
            {'course': 'Dip: Fashion (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 2, 'mathematical literacy': 3, 'technical mathematics': 3}],
             'any_other_subj': 15,
             'aps_mathematics': 21,
             'aps_literacy/technical_mathematics': 22},  # course 1

            {'course': 'Dip: Photography (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 2, 'mathematical literacy': 3, 'technical mathematics': 3}],
             'any_other_subj': 15,
             'aps_mathematics': 21,
             'aps_literacy/technical_mathematics': 22},  # course 2

            {'course': 'Dip: Graphic Design (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 2, 'mathematical literacy': 3, 'technical mathematics': 3}],
             'any_other_subj': 15,
             'aps_mathematics': 21,
             'aps_literacy/technical_mathematics': 22},  # course 3

            {'course': 'Dip: Fine Art (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 2, 'mathematical literacy': 3, 'technical mathematics': 3}],
             'any_other_subj': 15,
             'aps_mathematics': 21,
             'aps_literacy/technical_mathematics': 22},  # course 4

            {'course': 'Dip: Food Service Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 4},
                 {'other_1_subj': [
                     {'tourism': 4, 'accounting': 4, 'business studies': 4, 'consumer studies': 4}]}
             ],
             'any_other_subj': 9,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21},  # course 5

            {'course': 'Dip: tourism Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 4},
                 {'other_subj': [
                     {"sepedi": 4, "xitsonga": 4, "afrikaans": 4, "isizulu": 4, "tourism": 4,
                      "business studies": 4, "accounting": 4}]},
                 {'1_compulsory_subj': [
                     {'tourism': 4, 'geography': 4, 'business studies': 4, 'history': 4}
                 ]}
             ],
             'any_other_subj': 9,
             'aps_mathematics': 22,
             'aps_literacy/technical_mathematics': 23},  # course 6

            {'course': 'Dip: Public Relations (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 4},
                 {'other_subj': [
                     {"sepedi": 4, "xitsonga": 4, "afrikaans": 4, "isizulu": 4, "setswana": 4, "tourism": 4,
                      "business studies": 4, "accounting": 4}]}
             ],
             'any_other_subj': 9,
             'aps_mathematics': 22,
             'aps_literacy/technical_mathematics': 23},  # course 7

            {'course': 'Dip: Ecotourism Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'life science': 4, 'mathematics': 3, 'mathematical literacy': 4,
                  'technical mathematics': 4}
             ],
             'any_other_subj': 9,
             'aps_mathematics': 20},  # course 8

            {'course': 'Dip: Legal Assistance (3 years)',
             'compulsory_subj': [
                 {'english': 5, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 4},
                 {'other_subj': [{'sepedi': 3, 'afrikaans': 3, 'isizulu': 3}]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 23,
             'aps_literacy/technical_mathematics': 24},  # course 9

            {'course': 'Dip: Labour Law (3 years)',
             'compulsory_subj': [
                 {'english': 5, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 4},
                 {'other_subj': [{'sepedi': 3, 'afrikaans': 3, 'isizulu': 3}]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 23,
             'aps_literacy/technical_mathematics': 24},  # course 10

            {'course': 'Dip: Safety Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 4}
             ],
             'any_other_subj': 14,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21},  # course 11

            {'course': 'Dip: Policing (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 4},
                 {'other_subj': [{'sepedi': 4, 'afrikaans': 4, 'isizulu': 4}]}
             ],
             'any_other_subj': 10,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21},  # course 12

            {'course': 'BEd (Senior Phase & FET Teaching) (4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'technical mathematics': 4, 'mathematical literacy': 6,
                  'physical science': 3, 'technical science': 3}
             ],
             'any_other_subj': 11,
             'aps_mathematics': 22,
             'aps_literacy/technical_mathematics': 24},  # course 13

            {'course': 'Bachelor of Communication Studies (4 years)',
             'compulsory_subj': [
                 {'english': 5, 'mathematics': 3, 'mathematical literacy': 4, 'life orientation': 4},
                 {'other_subj': [{'sepedi': 4, 'afrikaans': 4, 'isizulu': 4}]}
             ],
             'any_other_subj': 8,
             'aps_mathematics': 24,
             'aps_mathematical_literacy': 25}  # course 14
        ]

        # COURSES FOR MANAGEMENT SCIENCE
        self.courses_management_science = [
            {'course': 'Dip: Financial Info. Systems (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'accounting': 4, 'mathematics': 3, 'mathematical literacy': 5,
                  'technical mathematics': 3}
             ],
             'any_other_subj': 9,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 22},  # course 1

            {'course': 'Dip: Cost & Man. Accounting (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'accounting': 4, 'mathematics': 3, 'mathematical literacy': 5,
                  'technical mathematics': 3}
             ],
             'any_other_subj': 9,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 22},  # course 2

            {'course': 'Dip: Internal Auditing (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'accounting': 4, 'mathematics': 3, 'mathematical literacy': 6,
                  'technical mathematics': 3}
             ],
             'any_other_subj': 9,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 23},  # course 3

            {'course': 'Dip: Human Resources Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 3}
             ],
             'any_other_subj': 13,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21},  # course 4

            {'course': 'Dip: Logistics and Supply Chain Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 3}
             ],
             'any_other_subj': 13,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21},  # course 5

            {'course': 'Dip: Marketing (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 3}
             ],
             'any_other_subj': 13,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21},  # course 6

            {'course': 'Dip: Retail Business Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 3}
             ],
             'any_other_subj': 13,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21},  # course 7

            {'course': 'Dip: Sport Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 3, 'mathematical literacy': 4, 'technical mathematics': 3}
             ],
             'any_other_subj': 13,
             'aps_mathematics': 20,
             'aps_literacy/technical_mathematics': 21}  # course 8
        ]

        # COURSES FOR ENGINEERING & TECHNOLOGY
        self.courses_engineering_technology = [
            {'course': 'Dip: Chemical Engineering (3 years)',
             'ext_course': 'Dip: Chemical Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 1

            {'course': 'Dip: Civil Engineering (3 years)',
             'ext_course': 'Dip: Civil Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 2

            {'course': 'Dip: Electronic Engineering (3 years)',
             'ext_course': 'Dip: Electronic Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 3

            {'course': 'Dip: Power Engineering (3 years)',
             'ext_course': 'Dip: Power Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24},  # course 4

            {'course': 'Dip: Process Control Engineering (3 years)',
             'ext_course': 'Dip: Process Control Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 5

            {'course': 'Dip: Computer Systems Engineering (3 years)',
             'ext_course': 'Dip: Computer Systems Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 6

            {'course': 'Dip: Industrial Engineering (3 years)',
             'ext_course': 'Dip: Industrial Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 7

            {'course': 'Dip: Mechanical Engineering (3 years)',
             'ext_course': 'Dip: Mechanical Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 8

            {'course': 'Dip: Metallurgical Engineering (3 years)',
             'ext_course': 'Dip: Metallurgical Engineering (Extended 4 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 4},
                 {'ext_subj': [
                     {'english': 3, 'mathematics': 3, 'physical science': 3}
                 ]}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24,
             'aps_exd': 22},  # course 9

            {'course': 'Dip: Operations Management (3 years)',
             'compulsory_subj': [
                 {'english': 4, 'mathematics': 4, 'physical science': 3}
             ],
             'any_other_subj': 12,
             'aps_mathematics': 24}  # course 10
        ]

        self.qualified_courses = []

    # METHODS FOR APPLIED COMPUTER SCIENCE FACULTY
    def aps_information_technology(self):
        aps2 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps2

    def aps_environmental_science(self):
        aps3 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics",
                               "physical science"])
        return aps3

    def aps_agricultural_management(self):
        aps4 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics",
                               "mathematical literacy"])
        return aps4

    def aps_biotechnology(self):
        aps5 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics",
                               "mathematics engineering", "physical science", "life science", "engineering science"])
        return aps5

    def aps_non_destructive_testing(self):
        aps6 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science", "life science",
                               "technical mathematics"])
        return aps6

    def aps_analytical_chemistry(self):
        aps8 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics",
                               "mathematics engineering", "physical science", "life science", "engineering science"])
        return aps8

    def aps_medical_lab_science(self):
        aps7 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science", "life science"])
        return aps7

    # METHODS FOR HUMAN SCIENCE FACULTY
    def aps_fashion(self):
        aps1 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps1

    def aps_photography(self):
        aps2 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps2

    def aps_graphic_design(self):
        aps3 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps3

    def aps_fine_art(self):
        aps4 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps4

    def aps_food_service_management(self):
        aps5 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "tourism", "business studies", "consumer studies"])
        return aps5

    def aps_tourism_management(self):
        aps6 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "tourism", "business studies", "consumer studies",
                               "sepedi", "isizulu", "afrikaans"])
        return aps6

    def aps_public_relations(self):
        aps7 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "tourism", "business studies", "consumer studies",
                               "sepedi", "isizulu", "afrikaans"])
        return aps7

    def aps_ecotourism_management(self):
        aps8 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "life science"])
        return aps8

    def aps_legal_assistance(self):
        aps9 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "sepedi", "isizulu", "afrikaans"])
        return aps9

    def aps_labour_law(self):
        aps10 = sum(value for key, value in self.subject_list.items() if
                    key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                                "technical mathematics", "sepedi", "isizulu", "afrikaans"])
        return aps10

    def aps_safety_management(self):
        aps11 = sum(value for key, value in self.subject_list.items() if
                    key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                                "technical mathematics"])
        return aps11

    def aps_policing(self):
        aps12 = sum(value for key, value in self.subject_list.items() if
                    key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                                "technical mathematics", "sepedi", "isizulu", "afrikaans"])
        return aps12

    def aps_teaching(self):
        aps13 = sum(value for key, value in self.subject_list.items() if
                    key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                                "technical mathematics", "physical science", "technical science"])
        return aps13

    def aps_communication_studies(self):
        aps14 = sum(value for key, value in self.subject_list.items() if
                    key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                                "sepedi", "isizulu", "afrikaans"])
        return aps14

    # METHODS FOR MANAGEMENT SCIENCE FACULTY
    def aps_financial_info_systems(self):
        aps1 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "accounting"])
        return aps1

    def aps_cos_man_accounting(self):
        aps2 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "accounting"])
        return aps2

    def aps_internal_auditing(self):
        aps3 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics", "accounting"])
        return aps3

    def aps_human_resource_management(self):
        aps4 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps4

    def aps_logistics_supply_chain(self):
        aps5 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps5

    def aps_marketing(self):
        aps6 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps6

    def aps_retail_business_management(self):
        aps7 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps7

    def aps_sport_management(self):
        aps8 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "mathematical literacy",
                               "technical mathematics"])
        return aps8

    # METHODS FOR ENGINEERING & TECHNOLOGY FACULTY
    def aps_chemical_engineering(self):
        aps1 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps1

    def aps_civil_engineering(self):
        aps2 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps2

    def aps_electronic_engineering(self):
        aps3 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps3

    def aps_power_engineering(self):
        aps4 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps4

    def aps_process_control_engineering(self):
        aps5 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps5

    def aps_computer_system_engineering(self):
        aps6 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps6

    def aps_industrial_engineering(self):
        aps7 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps7

    def aps_mechanical_engineering(self):
        aps8 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps8

    def aps_metallurgical_engineering(self):
        aps9 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps9

    def aps_operations_management(self):
        aps10 = sum(value for key, value in self.subject_list.items() if
                   key not in ["life orientation", "english", "mathematics", "physical science"])
        return aps10






