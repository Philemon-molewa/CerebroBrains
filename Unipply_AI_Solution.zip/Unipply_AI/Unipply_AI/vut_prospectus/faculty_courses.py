from faculty import Faculty


class FacultyCourses(Faculty):

    def check_req_information_technology(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[0]['compulsory_subj'][0]['english'] and \
                        self.subjects['mathematics'] >= \
                        self.courses1[0]['compulsory_subj'][0]['mathematics'] and int(self.aps) >= self.courses1[0].get(
                    'aps_mathematics/technical_mathematics') \
                        and int(self.aps_not_com_it) >= self.courses1[0].get('any_other_subj'):
                    q_course = self.courses1[0].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['english'] >= self.courses1[0]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematical literacy'] >= \
                        self.courses1[0]['compulsory_subj'][0]['mathematical literacy'] and int(self.aps) >= \
                        self.courses1[0].get(
                            'aps_mathematical_literacy') \
                        and int(self.aps_not_com_it) >= self.courses1[0].get('any_other_subj'):
                    q_course = self.courses1[0].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[0]['compulsory_subj'][0]['english'] and self.subjects[
                    'technical mathematics'] \
                        >= self.courses1[0]['compulsory_subj'][0]['technical mathematics'] and int(self.aps) >= \
                        self.courses1[0].get('aps_mathematical_literacy'):
                    q_course = self.courses1[0].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

        except KeyError:
            pass

    def check_req_environmental_science(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[1]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematics'] >= \
                        self.courses1[1]['compulsory_subj'][0]['mathematics'] and self.subjects['physical science'] >= \
                        self.courses1[1]['compulsory_subj'][0]['physical science'] and int(self.aps) >= \
                        self.courses1[1].get('aps_mathematics') \
                        and int(self.aps_not_com_es) >= self.courses1[1].get('any_other_subj'):
                    q_course = self.courses1[1].get('course')
                    self.qualified_courses.append(q_course)

                    print(q_course)
        except KeyError:
            pass

    def check_req_agricultural_management(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[2]['compulsory_subj'][0]['english'] and \
                        self.subjects['mathematics'] >= \
                        self.courses1[2]['compulsory_subj'][0]['mathematics'] and int(self.aps) >= self.courses1[2].get(
                    'aps_mathematics') \
                        and int(self.aps_not_com_am) >= self.courses1[2].get('any_other_subj'):
                    q_course = self.courses1[2].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['english'] >= self.courses1[2]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematical literacy'] >= \
                        self.courses1[2]['compulsory_subj'][0]['mathematical literacy'] and int(self.aps) >= \
                        self.courses1[2].get(
                            'aps_mathematical_literacy') \
                        and int(self.aps_not_com_am) >= self.courses1[2].get('any_other_subj'):
                    q_course = self.courses1[2].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

        except KeyError:
            pass

    def check_req_biotechnology(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[3]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematics'] >= \
                        self.courses1[3]['compulsory_subj'][0]['mathematics'] and self.subjects['life orientation'] >= \
                        self.courses1[3]['compulsory_subj'][0]['life orientation'] and int(self.aps) >= \
                        self.courses1[3].get('aps_mathematics/mathematics_engineering') and self.subjects[
                    'physical science'] >= \
                        self.courses1[3]['compulsory_subj'][0]['physical science'] and self.subjects['life science'] >= \
                        self.courses1[3]['compulsory_subj'][0]['life science'] and int(self.aps_not_com_bio) >= \
                        self.courses1[3].get('any_other_subj'):
                    q_course = self.courses1[3].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

            elif 'mathematics engineering' in self.subjects:
                if self.subjects['english'] >= self.courses1[3]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematics engineering'] >= \
                        self.courses1[3]['compulsory_subj'][0]['mathematics engineering'] and self.subjects[
                    'life orientation'] >= \
                        self.courses1[3]['compulsory_subj'][0]['life orientation'] and int(self.aps) >= \
                        self.courses1[3].get('aps_mathematics/mathematics_engineering') and self.subjects[
                    'life science'] >= \
                        self.courses1[3]['compulsory_subj'][0]['life science'] and int(self.aps_not_com_bio) >= \
                        self.courses1[3].get('any_other_subj') and self.subjects['engineering science'] >= \
                        self.courses1[3]['compulsory_subj'][0]['engineering science']:
                    q_course = self.courses1[3].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

        except KeyError:
            pass

    def check_req_non_destructive_testing(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[4]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematics'] >= \
                        self.courses1[4]['compulsory_subj'][0]['mathematics'] and self.subjects['physical science'] >= \
                        self.courses1[4]['compulsory_subj'][0]['physical science'] and self.subjects[
                    'life orientation'] >= \
                        self.courses1[4]['compulsory_subj'][0]['life orientation'] and int(self.aps) >= \
                        self.courses1[4].get('aps_mathematics') and int(self.aps_not_com_ndt) >= self.courses1[4].get(
                    'any_other_subj'):
                    q_course = self.courses1[4].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

                elif self.subjects['english'] >= self.courses1[4]['compulsory_subj'][1]['english'] and self.subjects[
                    'mathematics'] >= \
                        self.courses1[4]['compulsory_subj'][1]['mathematics'] and self.subjects['physical science'] >= \
                        self.courses1[4]['compulsory_subj'][1]['physical science'] and self.subjects[
                    'life orientation'] >= \
                        self.courses1[4]['compulsory_subj'][1]['life orientation'] and int(self.aps) >= \
                        self.courses1[4].get('aps_mathematics') and int(self.aps_not_com_ndt) >= self.courses1[4].get(
                    'any_other_subj'):
                    q_course = self.courses1[4].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[4]['compulsory_subj'][0]['english'] and self.subjects[
                    'technical mathematics'] >= \
                        self.courses1[4]['compulsory_subj'][0]['technical mathematics'] and self.subjects[
                    'physical science'] >= \
                        self.courses1[4]['compulsory_subj'][0]['physical science'] and self.subjects[
                    'life orientation'] >= \
                        self.courses1[4]['compulsory_subj'][0]['life orientation'] and int(self.aps) >= \
                        self.courses1[4].get('aps_technical_mathematics') and int(self.aps_not_com_ndt) >= \
                        self.courses1[4].get('any_other_subj'):
                    q_course = self.courses1[4].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

                elif self.subjects['english'] >= self.courses1[4]['compulsory_subj'][1]['english'] and self.subjects[
                    'technical mathematics'] >= \
                        self.courses1[4]['compulsory_subj'][1]['technical mathematics'] and self.subjects[
                    'physical science'] >= \
                        self.courses1[4]['compulsory_subj'][1]['physical science'] and self.subjects[
                    'life orientation'] >= \
                        self.courses1[4]['compulsory_subj'][1]['life orientation'] and int(self.aps) >= \
                        self.courses1[4].get('aps_technical_mathematics') and int(self.aps_not_com_ndt) >= \
                        self.courses1[4].get('any_other_subj'):
                    q_course = self.courses1[4].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

        except KeyError:
            pass

    def check_req_medical_laboratory_science(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[5]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematics'] >= \
                        self.courses1[5]['compulsory_subj'][0]['mathematics'] and self.subjects['physical science'] >= \
                        self.courses1[5]['compulsory_subj'][0]['physical science'] and self.subjects['life science'] >= \
                        self.courses1[5]['compulsory_subj'][0]['life science'] and self.subjects['life orientation'] >= \
                        self.courses1[5]['compulsory_subj'][0]['life orientation'] and int(self.aps) >= \
                        self.courses1[5].get('aps_mathematics') and int(self.aps_not_com_mls) >= self.courses1[5].get(
                    'any_other_subj'):
                    q_course = self.courses1[5].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

        except KeyError:
            pass

    def check_req_analytical_chemistry(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['english'] >= self.courses1[6]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematics'] >= \
                        self.courses1[6]['compulsory_subj'][0]['mathematics'] and self.subjects['life orientation'] >= \
                        self.courses1[6]['compulsory_subj'][0]['life orientation'] and int(self.aps) >= \
                        self.courses1[6].get('aps_mathematics/mathematics_engineering') and self.subjects[
                    'physical science'] >= \
                        self.courses1[6]['compulsory_subj'][0]['physical science'] and int(self.aps_not_com_ac) >= \
                        self.courses1[6].get('any_other_subj'):
                    q_course = self.courses1[6].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

            elif 'mathematics engineering' in self.subjects:
                if self.subjects['english'] >= self.courses1[6]['compulsory_subj'][0]['english'] and self.subjects[
                    'mathematics engineering'] >= \
                        self.courses1[6]['compulsory_subj'][0]['mathematics engineering'] and self.subjects[
                    'life orientation'] >= \
                        self.courses1[6]['compulsory_subj'][0]['life orientation'] and int(self.aps) >= \
                        self.courses1[6].get('aps_mathematics/mathematics_engineering') and int(self.aps_not_com_ac) >= \
                        self.courses1[6].get('any_other_subj') and self.subjects['engineering science'] >= \
                        self.courses1[6]['compulsory_subj'][0]['engineering science']:
                    q_course = self.courses1[6].get('course')
                    self.qualified_courses.append(q_course)
                    print(q_course)

        except KeyError:
            pass

    obj = Faculty()

    # for this class
    obj.sub()
    courses1 = obj.courses_applied_science
    courses2 = obj.courses_human_science
    courses3 = obj.courses_management_science
    courses4 = obj.courses_engineering_technology
    subjects = obj.subject_list  # to access the subjects of user
    # for Interface clss

    aps = obj.calculate_aps()
    print(f"\nAPS: {aps}\n")

    #  aps for remaining subjects
    aps_not_com_it = obj.aps_information_technology()
    aps_not_com_es = obj.aps_environmental_science()
    aps_not_com_am = obj.aps_agricultural_management()
    aps_not_com_bio = obj.aps_biotechnology()
    aps_not_com_ndt = obj.aps_non_destructive_testing()
    aps_not_com_mls = obj.aps_medical_lab_science()
    aps_not_com_ac = obj.aps_analytical_chemistry()

    #  METHODS FOR FACULTY OF HUMAN SCIENCE
    def check_req_fashion(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[0]['compulsory_subj'][0]['mathematics'] \
                        and self.subjects['english'] >= self.courses2[0]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_f) >= self.courses2[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[0].get('aps_mathematics'):
                    q_course = self.courses2[0].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses2[0]['compulsory_subj'][0][
                    'mathematical literacy'] \
                        and self.subjects['english'] >= self.courses2[0]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_f) >= self.courses2[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[0].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[0].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses2[0]['compulsory_subj'][0][('technical '
                                                                                                     'mathematics')] \
                        and self.subjects['english'] >= self.courses2[0]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_f) >= self.courses2[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[0].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[0].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_photography(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[1]['compulsory_subj'][0]['mathematics'] \
                        and self.subjects['english'] >= self.courses2[1]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_p) >= self.courses2[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[1].get('aps_mathematics'):
                    q_course = self.courses2[1].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses2[1]['compulsory_subj'][0][
                    'mathematical literacy'] \
                        and self.subjects['english'] >= self.courses2[1]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_p) >= self.courses2[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[1].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[1].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses2[1]['compulsory_subj'][0][('technical '
                                                                                                     'mathematics')] \
                        and self.subjects['english'] >= self.courses2[1]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_p) >= self.courses2[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[1].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[1].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_graphic_design(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[2]['compulsory_subj'][0]['mathematics'] \
                        and self.subjects['english'] >= self.courses2[2]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_gd) >= self.courses2[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[2].get('aps_mathematics'):
                    q_course = self.courses2[2].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses2[2]['compulsory_subj'][0][
                    'mathematical literacy'] \
                        and self.subjects['english'] >= self.courses2[2]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_gd) >= self.courses2[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[2].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[2].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses2[2]['compulsory_subj'][0][('technical '
                                                                                                     'mathematics')] \
                        and self.subjects['english'] >= self.courses2[2]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_gd) >= self.courses2[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[2].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[2].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_fine_art(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[3]['compulsory_subj'][0]['mathematics'] \
                        and self.subjects['english'] >= self.courses2[3]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_fa) >= self.courses2[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[3].get('aps_mathematics'):
                    q_course = self.courses2[3].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses2[3]['compulsory_subj'][0][
                    'mathematical literacy'] \
                        and self.subjects['english'] >= self.courses2[3]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_fa) >= self.courses2[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[3].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[3].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses2[3]['compulsory_subj'][0][('technical '
                                                                                                     'mathematics')] \
                        and self.subjects['english'] >= self.courses2[3]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_fa) >= self.courses2[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[3].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[3].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_food_service_management(self):
        try:
            if 'mathematics' or 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if 'tourism' or 'accounting' or 'business studies' or 'consumer studies' in \
                        self.subjects and self.subjects['tourism'] >= \
                        self.courses2[4]['compulsory_subj'][1]['other_1_subj'][0]['tourism'] or \
                        self.subjects['accounting'] >= self.courses2[4]['compulsory_subj'][1]['other_1_subj'][0][
                    'accounting'] \
                        or self.subjects['business studies'] >= \
                        self.courses2[4]['compulsory_subj'][1]['other_1_subj'][0]['business studies'] or \
                        self.subjects['consumer studies'] >= \
                        self.courses2[4]['compulsory_subj'][1]['other_1_subj'][0]['consumer studies'] and \
                        self.subjects['mathematics'] >= self.courses2[4]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['mathematical literacy'] >= self.courses2[4]['compulsory_subj'][0][
                    'mathematical literacy'] or \
                        self.subjects['technical mathematics'] >= self.courses2[4]['compulsory_subj'][0][
                    'technical mathematics'] and \
 \
                        self.subjects['english'] >= self.courses2[4]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_fsm) >= self.courses2[4].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[4].get('aps_mathematics'):
                    q_course = self.courses2[4].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_tourism_management(self):
        try:
            if 'mathematics' or 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if 'tourism' or 'accounting' or 'business studies' or 'consumer studies' in \
                        self.subjects and 'sepedi' or 'isizulu' or 'afrikaans' in \
                        self.subjects and self.subjects['tourism'] >= \
                        self.courses2[5]['compulsory_subj'][1]['other_subj'][0]['tourism'] or \
                        self.subjects['accounting'] >= self.courses2[5]['compulsory_subj'][1]['other_subj'][0][
                    'accounting'] \
                        or self.subjects['business studies'] >= \
                        self.courses2[5]['compulsory_subj'][1]['other_subj'][0]['business studies'] or \
                        self.subjects['consumer studies'] >= \
                        self.courses2[5]['compulsory_subj'][1]['other_subj']['consumer studies'] and \
                        self.subjects['sepedi'] >= self.courses2[5]['compulsory_subj'][1]['other_suj'][0]['sepedi'] or \
                        self.subjects['isizulu'] >= self.courses2[5]['compulsory_subj'][1]['other_suj'][0]['isizulu'] or \
                        self.subjects['afrikaans'] >= self.courses2[5]['compulsory_subj'][1]['other_suj'][0][
                    'afrikaans'] and \
                        self.subjects['tourism'] >= self.courses2[5]['compulsory_subj'][2]['1_compulsory_subj'][0][
                    'tourism'] or \
                        self.subjects['geography'] >= self.courses2[5]['compulsory_subj'][2]['1_compulsory_subj'][0][
                    'geography'] or \
                        self.subjects['business studies'] >= \
                        self.courses2[5]['compulsory_subj'][2]['1_compulsory_subj'][0]['business studies'] or \
                        self.subjects['history'] >= self.courses2[5]['compulsory_subj'][2]['1_compulsory_subj'][0][
                    'history'] and \
                        self.subjects['mathematics'] >= self.courses2[5]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['mathematical literacy'] >= self.courses2[5]['compulsory_subj'][0][
                    'mathematical literacy'] or \
                        self.subjects['technical mathematics'] >= self.courses2[5]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses2[5]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_tm) >= self.courses2[5].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[5].get('aps_mathematics'):
                    q_course = self.courses2[5].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_public_relations(self):
        try:
            if 'mathematics' or 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if 'tourism' or 'accounting' or 'business studies' or 'consumer studies' in \
                        self.subjects and 'sepedi' or 'isizulu' or 'afrikaans' in \
                        self.subjects and self.subjects['tourism'] >= \
                        self.courses2[6]['compulsory_subj'][1]['other_subj'][0]['tourism'] or \
                        self.subjects['accounting'] >= self.courses2[6]['compulsory_subj'][1]['other_subj'][0][
                    'accounting'] \
                        or self.subjects['business studies'] >= \
                        self.courses2[6]['compulsory_subj'][1]['other_subj'][0]['business studies'] or \
                        self.subjects['consumer studies'] >= \
                        self.courses2[6]['compulsory_subj'][1]['other_subj'][0]['consumer studies'] and \
                        self.subjects['sepedi'] >= self.courses2[6]['compulsory_subj'][1]['other_suj'][0]['sepedi'] or \
                        self.subjects['isizulu'] >= self.courses2[6]['compulsory_subj'][1]['other_suj'][0]['isizulu'] or \
                        self.subjects['afrikaans'] >= self.courses2[6]['compulsory_subj'][1]['other_suj'][0][
                    'afrikaans'] and \
                        self.subjects['mathematics'] >= self.courses2[6]['compulsory_subj'][0]['mathematics'] or \
                        self.subjects['mathematical literacy'] >= self.courses2[6]['compulsory_subj'][0][
                    'mathematical literacy'] or \
                        self.subjects['technical mathematics'] >= self.courses2[6]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses2[6]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_pr) >= self.courses2[6].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[6].get('aps_mathematics'):
                    q_course = self.courses2[6].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_ecotourism_management(self):
        try:
            if 'mathematics' or 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[7]['compulsory_subj'][0]['mathematics'] or \
                        self.subjects['mathematical literacy'] >= self.courses2[7]['compulsory_subj'][0][
                    'mathematical literacy'] or \
                        self.subjects['technical mathematics'] >= self.courses2[7]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses2[7]['compulsory_subj'][0]['english'] and \
                        self.subjects['life science'] >= self.courses2[7]['compulsory_subj'][0]['life science'] and \
                        int(self.aps_not_com_em) >= self.courses2[7].get('any_other_sbj') and \
                        int(self.aps) >= self.courses2[7].get('aps_mathematics'):
                    q_course = self.courses2[7].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_legal_assistance(self):
        try:
            if 'mathematics' in self.subjects:
                if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                    if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                        if self.subjects['mathematics'] >= self.courses2[8]['compulsory_subj'][0]['mathematics'] and \
                                self.subjects['english'] >= self.courses2[8]['compulsory_subj'][0]['english'] and \
                                self.subjects['sepedi'] >= self.courses2[8]['compulsory_subj'][1]['other_subj'][0][
                            'sepedi'] or \
                                self.subjects['afrikaans'] >= self.courses2[8]['compulsory_subj'][1]['other_subj'][0][
                            'afrikaans'] or \
                                self.subjects['isizulu'] >= self.courses2[8]['compulsory_subj'][1]['other_subj'][0][
                            'isizulu'] and \
                                int(self.aps_not_com_la) >= self.courses2[8].get('any_other_subj') and \
                                int(self.aps) >= self.courses2[8].get('aps_mathematics'):
                            q_course = self.courses2[8].get('course')
                            print(q_course)

            elif 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                    if self.subjects['mathematical literacy'] >= self.courses2[8]['compulsory_subj'][0][
                        'mathematical literacy'] or \
                            self.subjects['technical mathematics'] >= self.courses2[8]['compulsory_subj'][0][
                        'technical mathematics'] and \
                            self.subjects['english'] >= self.courses2[8]['compulsory_subj'][0]['english'] and \
                            self.subjects['sepedi'] >= self.courses2[8]['compulsory_subj'][1]['other_subj'][0][
                        'sepedi'] or \
                            self.subjects['afrikaans'] >= self.courses2[8]['compulsory_subj'][1]['other_subj'][0][
                        'afrikaans'] or \
                            self.subjects['isizulu'] >= self.courses2[8]['compulsory_subj'][1]['other_subj'][0][
                        'isizulu'] and \
                            int(self.aps_not_com_la) >= self.courses2[8].get('any_other_subj') and \
                            int(self.aps) >= self.courses2[8].get('aps_mathematics'):
                        q_course = self.courses2[8].get('course')
                        print(q_course)

        except KeyError:
            pass

    def check_req_labour_law(self):
        try:
            if 'mathematics' in self.subjects:
                if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                    if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                        if self.subjects['mathematics'] >= self.courses2[9]['compulsory_subj'][0]['mathematics'] and \
                                self.subjects['english'] >= self.courses2[9]['compulsory_subj'][0]['english'] and \
                                self.subjects['sepedi'] >= self.courses2[9]['compulsory_subj'][1]['other_subj'][0][
                            'sepedi'] or \
                                self.subjects['afrikaans'] >= self.courses2[9]['compulsory_subj'][1]['other_subj'][0][
                            'afrikaans'] or \
                                self.subjects['isizulu'] >= self.courses2[9]['compulsory_subj'][1]['other_subj'][0][
                            'isizulu'] and \
                                int(self.aps_not_com_ll) >= self.courses2[9].get('any_other_subj') and \
                                int(self.aps) >= self.courses2[9].get('aps_mathematics'):
                            q_course = self.courses2[9].get('course')
                            print(q_course)

            elif 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                    if self.subjects['mathematical literacy'] >= self.courses2[9]['compulsory_subj'][0][
                        'mathematical literacy'] or \
                            self.subjects['technical mathematics'] >= self.courses2[9]['compulsory_subj'][0][
                        'technical mathematics'] and \
                            self.subjects['english'] >= self.courses2[9]['compulsory_subj'][0]['english'] and \
                            self.subjects['sepedi'] >= self.courses2[9]['compulsory_subj'][1]['other_subj'][0][
                        'sepedi'] or \
                            self.subjects['afrikaans'] >= self.courses2[9]['compulsory_subj'][1]['other_subj'][0][
                        'afrikaans'] or \
                            self.subjects['isizulu'] >= self.courses2[9]['compulsory_subj'][1]['other_subj'][0][
                        'isizulu'] and \
                            int(self.aps_not_com_ll) >= self.courses2[9].get('any_other_subj') and \
                            int(self.aps) >= self.courses2[9].get('aps_mathematics'):
                        q_course = self.courses2[9].get('course')
                        print(q_course)

        except KeyError:
            pass

    def check_req_safety_management(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[10]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses2[10]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_sm) >= self.courses2[10].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[10].get('aps_mathematics'):
                    q_course = self.courses2[10].get('course')
                    print(q_course)

            elif 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses2[10]['compulsory_subj'][0][
                    'mathematical literacy'] or \
                        self.subjects['technical mathematics'] >= self.courses2[10]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses2[10]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_sm) >= self.courses2[10].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[10].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[10].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_policing(self):
        try:
            if 'mathematics' in self.subjects:
                if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                    if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                        if self.subjects['mathematics'] >= self.courses2[11]['compulsory_subj'][0]['mathematics'] and \
                                self.subjects['english'] >= self.courses2[11]['compulsory_subj'][0]['english'] and \
                                self.subjects['sepedi'] >= self.courses2[11]['compulsory_subj'][1]['other_subj'][0][
                            'sepedi'] or \
                                self.subjects['afrikaans'] >= self.courses2[11]['compulsory_subj'][1]['other_subj'][0][
                            'afrikaans'] or \
                                self.subjects['isizulu'] >= self.courses2[11]['compulsory_subj'][1]['other_subj'][0][
                            'isizulu'] and \
                                int(self.aps_not_com_ll) >= self.courses2[11].get('any_other_subj') and \
                                int(self.aps) >= self.courses2[11].get('aps_mathematics'):
                            q_course = self.courses2[11].get('course')
                            print(q_course)

            elif 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if 'sepedi' or 'afrikaans' or 'isizulu' in self.subjects:
                    if self.subjects['mathematical literacy'] >= self.courses2[11]['compulsory_subj'][0][
                        'mathematical literacy'] and \
                            self.subjects['english'] >= self.courses2[11]['compulsory_subj'][0]['english'] and \
                            self.subjects['sepedi'] >= self.courses2[11]['compulsory_subj'][1]['other_subj'][0][
                        'sepedi'] or \
                            self.subjects['afrikaans'] >= self.courses2[11]['compulsory_subj'][1]['other_subj'][0][
                        'afrikaans'] or \
                            self.subjects['isizulu'] >= self.courses2[11]['compulsory_subj'][1]['other_subj'][0][
                        'isizulu'] and \
                            int(self.aps_not_com_ll) >= self.courses2[11].get('any_other_subj') and \
                            int(self.aps) >= self.courses2[11].get('aps_literacy/technical_mathematics'):
                        q_course = self.courses2[11].get('course')
                        print(q_course)

        except KeyError:
            pass

    def check_req_teaching(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[12]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses2[12]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses2[12]['compulsory_subj'][0][
                    'physical science'] or \
                        self.subjects['technical science'] >= self.courses2[12]['compulsory_subj'][0][
                    'technical science'] and \
                        int(self.aps_not_com_t) >= self.courses2[12].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[12].get('aps_mathematics'):
                    q_course = self.courses2[12].get('course')
                    print(q_course)

            elif 'mathematical literacy' or 'technical mathematics' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses2[12]['compulsory_subj'][0][
                    'mathematical literacy'] or \
                        self.subjects['technical mathematics'] >= self.courses2[12]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses2[12]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses2[12]['compulsory_subj'][0][
                    'physical science'] or \
                        self.subjects['technical science'] >= self.courses2[12]['compulsory_subj'][0][
                    'technical science'] and \
                        int(self.aps_not_com_t) >= self.courses2[12].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[12].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses2[12].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_communication_studies(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses2[13]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses2[13]['compulsory_subj'][0]['english'] and \
                        self.subjects['life orientation'] >= self.courses2[13]['compulsory_subj'][0][
                    'life orientation'] and \
                        self.subjects['sepedi'] >= self.courses2[13]['compulsory_subj'][1]['other_subj'][0]['sepedi'] or \
                        self.subjects['afrikaans'] >= self.courses2[13]['compulsory_subj'][1]['other_subj'][0][
                    'afrikaans'] or \
                        self.subjects['isizulu'] >= self.courses2[13]['compulsory_subj'][1]['other_subj'][0][
                    'isizulu'] and \
                        int(self.aps_not_com_cs) >= self.courses2[13].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[13].get('aps_mathematics'):
                    q_course = self.courses2[13].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses2[13]['compulsory_subj'][0][
                    'mathematical literacy'] and \
                        self.subjects['english'] >= self.courses2[13]['compulsory_subj'][0]['english'] and \
                        self.subjects['life orientation'] >= self.courses2[13]['compulsory_subj'][0][
                    'life orientation'] and \
                        self.subjects['sepedi'] >= self.courses2[13]['compulsory_subj'][1]['other_subj'][0]['sepedi'] or \
                        self.subjects['afrikaans'] >= self.courses2[13]['compulsory_subj'][1]['other_subj'][0][
                    'afrikaans'] or \
                        self.subjects['isizulu'] >= self.courses2[13]['compulsory_subj'][1]['other_subj'][0][
                    'isizulu'] and \
                        int(self.aps_not_com_cs) >= self.courses2[13].get('any_other_subj') and \
                        int(self.aps) >= self.courses2[13].get('aps_mathematical_literacy'):
                    q_course = self.courses2[13].get('course')
                    print(q_course)

        except KeyError:
            pass

    #  aps for remaining subjects
    aps_not_com_f = obj.aps_fashion()
    aps_not_com_p = obj.aps_photography()
    aps_not_com_gd = obj.aps_graphic_design()
    aps_not_com_fa = obj.aps_fine_art()
    aps_not_com_fsm = obj.aps_food_service_management()
    aps_not_com_tm = obj.aps_tourism_management()
    aps_not_com_pr = obj.aps_public_relations()
    aps_not_com_em = obj.aps_ecotourism_management()
    aps_not_com_la = obj.aps_legal_assistance()
    aps_not_com_ll = obj.aps_labour_law()
    aps_not_com_sm = obj.aps_safety_management()
    aps_not_com_pl = obj.aps_policing()
    aps_not_com_t = obj.aps_teaching()
    aps_not_com_cs = obj.aps_communication_studies()

    # METHODS FOR FACULTY OF MANAGEMENT SCIENCE
    def check_req_financial_info_systems(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[0]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[0]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[0]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_fis) >= self.courses3[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[0].get('aps_mathematics'):
                    q_course = self.courses3[0].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[0]['compulsory_subj'][0][('mathematical '
                                                                                                     'literacy')] and \
                        self.subjects['english'] >= self.courses3[0]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[0]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_fis) >= self.courses3[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[0].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[0].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[0]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[0]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[0]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_fis) >= self.courses3[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[0].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[0].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_cos_man_accounting(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[1]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[1]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[1]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_cma) >= self.courses3[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[1].get('aps_mathematics'):
                    q_course = self.courses3[1].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[1]['compulsory_subj'][0][('mathematical '
                                                                                                     'literacy')] and \
                        self.subjects['english'] >= self.courses3[1]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[1]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_cma) >= self.courses3[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[1].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[1].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[1]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[1]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[1]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_cma) >= self.courses3[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[1].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[1].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_internal_auditing(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[2]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[2]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[2]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_itg) >= self.courses3[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[2].get('aps_mathematics'):
                    q_course = self.courses3[2].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[2]['compulsory_subj'][0][('mathematical '
                                                                                                     'literacy')] and \
                        self.subjects['english'] >= self.courses3[2]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[2]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_itg) >= self.courses3[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[2].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[2].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[2]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[2]['compulsory_subj'][0]['english'] and \
                        self.subjects['accounting'] >= self.courses3[2]['compulsory_subj'][0]['accounting'] and \
                        int(self.aps_not_com_itg) >= self.courses3[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[2].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[2].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_human_resource_management(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[3]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[3]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_hrm) >= self.courses3[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[3].get('aps_mathematics'):
                    q_course = self.courses3[3].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[3]['compulsory_subj'][0][
                    'mathematical literacy'] and \
                        self.subjects['english'] >= self.courses3[3]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_hrm) >= self.courses3[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[3].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[3].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[3]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[3]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_hrm) >= self.courses3[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[3].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[3].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_logistics_supply_chain(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[4]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[4]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_lsc) >= self.courses3[4].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[4].get('aps_mathematics'):
                    q_course = self.courses3[4].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[4]['compulsory_subj'][0][
                    'mathematical literacy'] and \
                        self.subjects['english'] >= self.courses3[4]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_lsc) >= self.courses3[4].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[4].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[4].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[4]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[4]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_lsc) >= self.courses3[4].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[4].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[4].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_marketing(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[5]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[5]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_m) >= self.courses3[5].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[5].get('aps_mathematics'):
                    q_course = self.courses3[5].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[5]['compulsory_subj'][0][
                    'mathematical literacy'] and \
                        self.subjects['english'] >= self.courses3[5]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_m) >= self.courses3[5].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[5].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[5].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[5]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[5]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_m) >= self.courses3[5].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[5].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[5].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_retail_business_management(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[6]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[6]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_rbm) >= self.courses3[6].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[6].get('aps_mathematics'):
                    q_course = self.courses3[6].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[6]['compulsory_subj'][0][
                    'mathematical literacy'] and \
                        self.subjects['english'] >= self.courses3[6]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_rbm) >= self.courses3[6].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[6].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[6].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[6]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[6]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_lsc) >= self.courses3[6].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[6].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[6].get('course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_sport_management(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses3[7]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses3[7]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_spm) >= self.courses3[7].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[7].get('aps_mathematics'):
                    q_course = self.courses3[7].get('course')
                    print(q_course)

            elif 'mathematical literacy' in self.subjects:
                if self.subjects['mathematical literacy'] >= self.courses3[7]['compulsory_subj'][0][
                    'mathematical literacy'] and \
                        self.subjects['english'] >= self.courses3[7]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_spm) >= self.courses3[7].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[7].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[7].get('course')
                    print(q_course)

            elif 'technical mathematics' in self.subjects:
                if self.subjects['technical mathematics'] >= self.courses3[7]['compulsory_subj'][0][
                    'technical mathematics'] and \
                        self.subjects['english'] >= self.courses3[7]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_spm) >= self.courses3[7].get('any_other_subj') and \
                        int(self.aps) >= self.courses3[7].get('aps_literacy/technical_mathematics'):
                    q_course = self.courses3[7].get('course')
                    print(q_course)

        except KeyError:
            pass

    # aps for remaining subjects
    aps_not_com_fis = obj.aps_financial_info_systems()
    aps_not_com_cma = obj.aps_cos_man_accounting()
    aps_not_com_itg = obj.aps_internal_auditing()
    aps_not_com_hrm = obj.aps_human_resource_management()
    aps_not_com_lsc = obj.aps_logistics_supply_chain()
    aps_not_com_m = obj.aps_marketing()
    aps_not_com_rbm = obj.aps_retail_business_management()
    aps_not_com_spm = obj.aps_sport_management()

    # METHODS FOR FACULTY OF ENGINEERING & TECHNOLOGY
    def check_req_chemical_engineering(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[0]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[0]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[0]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_chem) >= self.courses4[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[0].get('aps_mathematics'):
                    q_course = self.courses4[0].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[0]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[0]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[0]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_chem) >= self.courses4[0].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[0].get('aps_exd'):
                    q_course = self.courses4[0].get('ext_course')
                    print(q_course)

        except KeyError:
            pass

    def check_req_civil_engineering(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[1]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[1]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[1]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_ce) >= self.courses4[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[1].get('aps_mathematics'):
                    q_course = self.courses4[1].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[1]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[1]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[1]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_ce) >= self.courses4[1].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[1].get('aps_exd'):
                    q_course = self.courses4[1].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_electronic_engineering(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[2]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[2]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[2]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_e) >= self.courses4[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[2].get('aps_mathematics'):
                    q_course = self.courses4[2].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[2]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[2]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[2]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_e) >= self.courses4[2].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[2].get('aps_exd'):
                    q_course = self.courses4[2].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_power(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[3]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[3]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[3]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_pow) >= self.courses4[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[3].get('aps_mathematics'):
                    q_course = self.courses4[3].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[3]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[3]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[3]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_pow) >= self.courses4[3].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[3].get('aps_mathematics'):
                    q_course = self.courses4[3].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_process_control_engineering(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[4]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[4]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[4]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_pce) >= self.courses4[4].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[4].get('aps_mathematics'):
                    q_course = self.courses4[4].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[4]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[4]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[4]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_pce) >= self.courses4[4].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[4].get('aps_exd'):
                    q_course = self.courses4[4].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_computer_systems_engineering(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[5]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[5]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[5]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_cse) >= self.courses4[5].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[5].get('aps_mathematics'):
                    q_course = self.courses4[5].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[5]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[5]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[5]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_cse) >= self.courses4[5].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[5].get('aps_exd'):
                    q_course = self.courses4[5].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_industrial_engineering(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[6]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[6]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[6]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_ie) >= self.courses4[6].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[6].get('aps_mathematics'):
                    q_course = self.courses4[6].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[6]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[6]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[6]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_ie) >= self.courses4[6].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[6].get('aps_exd'):
                    q_course = self.courses4[6].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_mechanical_engineering(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[7]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[7]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[7]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_mech) >= self.courses4[7].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[7].get('aps_mathematics'):
                    q_course = self.courses4[7].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[7]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[7]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[7]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_mech) >= self.courses4[7].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[7].get('aps_exd'):
                    q_course = self.courses4[7].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_metallurgical(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[8]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[8]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[8]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_meta) >= self.courses4[8].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[8].get('aps_mathematics'):
                    q_course = self.courses4[8].get('course')
                    print(q_course)

                if self.subjects['mathematics'] >= self.courses4[8]['compulsory_subj'][1]['ext_subj'][0][
                    'mathematics'] and \
                        self.subjects['english'] >= self.courses4[8]['compulsory_subj'][1]['ext_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[8]['compulsory_subj'][1]['ext_subj'][0][
                    'physical science'] and \
                        int(self.aps_not_com_meta) >= self.courses4[8].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[8].get('aps_exd'):
                    q_course = self.courses4[8].get('ext_course')
                    print(q_course)
        except KeyError:
            pass

    def check_req_operations_management(self):
        try:
            if 'mathematics' in self.subjects:
                if self.subjects['mathematics'] >= self.courses4[9]['compulsory_subj'][0]['mathematics'] and \
                        self.subjects['english'] >= self.courses4[9]['compulsory_subj'][0]['english'] and \
                        self.subjects['physical science'] >= self.courses4[9]['compulsory_subj'][0]['english'] and \
                        int(self.aps_not_com_om) >= self.courses4[9].get('any_other_subj') and \
                        int(self.aps) >= self.courses4[9].get('aps_mathematics'):
                    q_course = self.courses4[9].get('course')
                    print(q_course)
        except KeyError:
            pass

    # aps for remaining subjects
    aps_not_com_chem = obj.aps_chemical_engineering()
    aps_not_com_ce = obj.aps_civil_engineering()
    aps_not_com_e = obj.aps_electronic_engineering()
    aps_not_com_pow = obj.aps_power_engineering()
    aps_not_com_pce = obj.aps_process_control_engineering()
    aps_not_com_cse = obj.aps_computer_system_engineering()
    aps_not_com_ie = obj.aps_industrial_engineering()
    aps_not_com_mech = obj.aps_mechanical_engineering()
    aps_not_com_meta = obj.aps_metallurgical_engineering()
    aps_not_com_om = obj.aps_operations_management()
