from faculty_courses import FacultyCourses
from user_interface import Interface

obj = FacultyCourses()


#  FOR APPLIED AND COMPUTER SCIENCE FACULTY


def run_functions_applied():
    print("FACULTY OF APPLIED AND COMPUTER SCIENCE")
    obj.check_req_medical_laboratory_science()
    obj.check_req_biotechnology()
    obj.check_req_non_destructive_testing()
    obj.check_req_agricultural_management()
    obj.check_req_environmental_science()
    obj.check_req_information_technology()
    obj.check_req_analytical_chemistry()
    print("  *NSFAS: National Student Financial Aid Scheme for all eligible students")
    print("  *CISCO BURSARY: Bursary for students enrolled in faculy of applied and computer science courses")
    print("  *AMAZON RECRUITMENT BURSARY: Bursary for students enrolled in faculy of applied and computer science courses")
run_functions_applied()


#  FOR HUMAN SCIENCE FACULTY


def run_functions_human():
    print("\nFACULTY OF HUMAN SCIENCE")
    obj.check_req_fashion()
    obj.check_req_photography()
    obj.check_graphic_design()
    obj.check_req_fine_art()
    obj.check_req_food_service_management()
    obj.check_req_tourism_management()
    obj.check_req_public_relations()
    obj.check_req_ecotourism_management()
    obj.check_req_legal_assistance()
    obj.check_req_labour_law()
    obj.check_req_safety_management()
    obj.check_req_policing()
    obj.check_req_teaching()
    obj.check_req_communication_studies()
    print("  *NSFAS: National Student Financial Aid Scheme for all eligible students")
    print("  *FUNDZA LUSHAKA: Bursary for teaching course only")


run_functions_human()


# FOR MANAGEMENT SCIENCE FACULTY


def run_functions_management():
    print("\nFACULTY OF MANAGEMENT SCIENCE")
    obj.check_req_financial_info_systems()
    obj.check_req_cos_man_accounting()
    obj.check_req_internal_auditing()
    obj.check_req_human_resource_management()
    obj.check_req_logistics_supply_chain()
    obj.check_req_marketing()
    obj.check_req_retail_business_management()
    obj.check_req_sport_management()
    print("  *NSFAS: National Student Financial Aid Scheme for all eligible students")
    print("  *TELKOM BURSARY: for students enrolled in the faculty of management science faculty")
    print("  *TETA BURSARY: Bursary for students enrolled in faculty of management science courses")

run_functions_management()


# FOR ENGINEERING & TECHNOLOGY


def run_functions_engineering():
    print("\nFACULTY OF ENGINEERING & TECHNOLOGY")
    obj.check_req_chemical_engineering()
    obj.check_req_civil_engineering()
    obj.check_req_electronic_engineering()
    obj.check_req_power()
    obj.check_req_process_control_engineering()
    obj.check_req_computer_systems_engineering()
    obj.check_req_industrial_engineering()
    obj.check_req_mechanical_engineering()
    obj.check_req_metallurgical()
    obj.check_req_operations_management()
    print("  *NSFAS: National Student Financial Aid Scheme for all eligible students")
    print("  *ESKOM: Bursary for students enrolled in engineering courses")


run_functions_engineering()
