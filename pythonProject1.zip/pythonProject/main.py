# Dataset for courses and qualifications across faculties
faculties = {
    "Engineering & Technology": [
        {"qualification": "Diploma", "course_name": "Chemical Engineering",
         "min_aps": 24, "subject_requirements": {"Mathematics": 4, "Physical Sciences": 4, "English": 4, "Home Language": 4}},
        {"qualification": "Diploma", "course_name": "Civil Engineering",
         "min_aps": 24, "subject_requirements": {"Mathematics": 4, "Physical Sciences": 4, "English": 4, "Home Language": 4}},
        {"qualification": "Diploma", "course_name": "Computer Systems Engineering",
         "min_aps": 24, "subject_requirements": {"Mathematics": 4, "Physical Sciences": 4, "English": 4, "Home Language": 4}},
    ],
    "Accountancy": [
        {"course_name": "Financial Information Systems",
         "min_aps": 20, "subject_requirements": {"Accounting": 4, "English": 4, "Mathematics": 3, "Home Language": 4}},
        {"course_name": "Cost & Management Accounting",
         "min_aps": 20, "subject_requirements": {"Accounting": 4, "English": 4, "Mathematics": 3, "Home Language": 4}},
        {"course_name": "Internal Auditing",
         "min_aps": 21, "subject_requirements": {"Accounting": 4, "English": 4, "Mathematics": 3, "Home Language": 4}},
    ],
    "Human Resources Management": [
        {"course_name": "Human Resources Management",
         "min_aps": 20, "subject_requirements": {"English": 4, "Mathematics": 3, "Home Language": 4}},
    ],
    "Logistics and Supply Chain Management": [
        {"course_name": "Logistics and Supply Chain Management",
         "min_aps": 20, "subject_requirements": {"English": 4, "Mathematics": 3, "Home Language": 4}},
    ],
    "Human Sciences": [
        {"course_name": "Diploma in Fashion",
         "min_aps": 21, "subject_requirements": {"English": 4, "Mathematics": 2, "Home Language": 4}},
        {"course_name": "Diploma in Photography",
         "min_aps": 21, "subject_requirements": {"English": 4, "Mathematics": 2, "Home Language": 4}},
    ],
    "Applied and Computer Science": [
        {"course_name": "Analytical Chemistry",
         "min_aps": 24, "subject_requirements": {"English": 4, "Mathematics": 4, "Physical Sciences": 4, "Home Language": 4}},
        {"course_name": "Biotechnology",
         "min_aps": 26, "subject_requirements": {"English": 4, "Mathematics": 4, "Physical Sciences": 4, "Life Sciences": 4, "Home Language": 4}},
    ]
}

# Calculate APS function
def calculate_aps(subject_grades):
    return sum(subject_grades.values())

# Course recommendation function
def recommend_courses(aps, subject_grades):
    matching_courses = []

    # If APS is 24 or higher, qualify for all courses
    if aps >= 24:
        for faculty, course_list in faculties.items():
            for course in course_list:
                matching_courses.append({
                    "course_name": course["course_name"],
                    "faculty": faculty,
                    "qualification": course.get("qualification", "Diploma")
                })
    else:
        # Filter courses based on APS and subject requirements
        for faculty, course_list in faculties.items():
            for course in course_list:
                meets_requirements = all(
                    subject_grades.get(subj, 0) >= level for subj, level in course["subject_requirements"].items()
                )
                if meets_requirements and aps >= course["min_aps"]:
                    matching_courses.append({
                        "course_name": course["course_name"],
                        "faculty": faculty,
                        "qualification": course.get("qualification", "Diploma")
                    })

    return matching_courses

# Main AI Assistant logic
def ai_assistant():
    print("Enter your 7 subjects and their grade levels (1-7 scale).")

    # Updated subjects list
    available_subjects = [
        "English", "Mathematics", "Physical Sciences", "Mathematical Literacy",
        "Life Sciences", "Accounting", "Business Studies", "Life Orientation",
        "Geography", "Tourism", "Religion Studies",
        "Xitsonga", "Sepedi", "isiZulu", "isiXhosa", "Sesotho",
        "Setswana", "siSwati", "Tshivenda", "Technical Mathematics"
    ]

    # Input subject grades
    subject_grades = {}
    for _ in range(7):
        subject = input("\nEnter the subject name: ").strip().title()
        if subject not in available_subjects:
            print("Invalid subject. Please try again.")
            continue

        try:
            grade = int(input(f"Enter your grade for {subject} (1-7): "))
            if 1 <= grade <= 7:
                subject_grades[subject] = grade
            else:
                print("Grade must be between 1 and 7.")
        except ValueError:
            print("Invalid input. Please enter a numeric value.")
            continue

    # Calculate APS and display it
    aps = calculate_aps(subject_grades)
    print(f"\nYour APS score is: {aps}")

    # Recommend courses
    matching_courses = recommend_courses(aps, subject_grades)

    if not matching_courses:
        print("Sorry, no matching courses found for your APS and subject grades.")
        return

    print("\nYou qualify for the following courses:")
    for course in matching_courses:
        print(f"- {course['qualification']} in {course['course_name']} (Faculty: {course['faculty']})")

    # NSFAS bursary recommendation
    if matching_courses:
        print("\nCongratulations! You are eligible to apply for an NSFAS bursary for these courses.")

# Run the AI Assistant
ai_assistant()
